import 'package:assignment_sqflite_todo/DB/db_hand.dart';
import 'package:flutter/material.dart';

import '../Model/model.dart';
import 'appupdate.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  DBhelper? dBhelp;
  late Future<List<TodoModel>> dataList;

  @override
  void initState() {
    super.initState();
    dBhelp = DBhelper();
    loadData();
  }

  loadData() async {
    dataList = dBhelp!.getDataList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const Drawer(),
      appBar: AppBar(
        title: const Text('Home Todo'),
        centerTitle: true,
        elevation: 0,
        actions: const [
          Padding(
              padding: EdgeInsets.only(right: 10),
              child: Icon(Icons.help_outline_rounded, size: 30)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
              child: FutureBuilder(
            future: dataList,
            builder: (context, AsyncSnapshot<List<TodoModel>> snapshot) {
              if (!snapshot.hasData || snapshot.data == null) {
                return const Center(
                  child: CircularProgressIndicator(),
                );
              } else if (snapshot.data!.length == 0) {
                return const Center(
                  child: Text('No Task to do'),
                );
              } else {
                return ListView.builder(
                    shrinkWrap: true,
                    itemCount: snapshot.data?.length,
                    itemBuilder: (context, index) {
                      int todoId = snapshot.data![index].id!.toInt();
                      String todoTitle = snapshot.data![index].title.toString();
                      String todoDisc = snapshot.data![index].title.toString();
                      String todoDT = snapshot.data![index].title.toString();
                      return Dismissible(
                        key: ValueKey<int>(todoId),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          color: Colors.red,
                          child: const Icon(
                            Icons.delete_forever,
                            color: Colors.white,
                          ),
                        ),
                        onDismissed: (DismissDirection direction) {
                          setState(() {});
                        },
                        child: Container(
                          decoration: const BoxDecoration(
                            color: Colors.yellow,
                          ),
                          child: Column(
                            children: [
                              ListTile(
                                contentPadding: const EdgeInsets.all(10),
                                title: Padding(
                                  padding: const EdgeInsets.only(bottom: 30),
                                  child: Text(
                                    todoTitle,
                                    style: const TextStyle(fontSize: 19),
                                  ),
                                ),
                                subtitle: Text(
                                  todoDisc,
                                ),
                              ),
                              const Divider(
                                color: Colors.black,
                                thickness: 0.8,
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 3, horizontal: 10),
                                child: Row(
                                  children: [
                                    Text(
                                      todoDT,
                                      style: const TextStyle(fontSize: 14),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    });
              }
            },
          )),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.purple,
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const AddupTask(),
              ));
        },
      ),
    );
  }
}
